[Course home](README.md) · **Trainer guide**

# Trainer guide

Everything to prepare before Day 1. Allow **two to three weeks**: downloads, environment builds and the
pre-computed pipeline runs each take hours, and every command in the course should be run once on the course
server before participants arrive.

## Contents

1. [Timeline](#1-timeline)
2. [Hardware](#2-hardware)
3. [The shared folder](#3-the-shared-folder)
4. [Training data](#4-training-data)
5. [Databases](#5-databases)
6. [Software environments](#6-software-environments)
7. [Pre-computed results](#7-pre-computed-results)
8. [Known gaps and decisions for you](#8-known-gaps-and-decisions-for-you)

---

## 1. Timeline

| When | Task |
| --- | --- |
| 3 weeks before | Server accounts; create `$SHARED`; build environments (section 6) |
| 3 weeks before | Download data (section 4) and databases (section 5) |
| 2 weeks before | Run the pipeline on the training and capstone sets (section 7) |
| 2 weeks before | Pre-compute the manual steps (section 7) |
| 1 week before | Dry run: one trainer works through every page, Day 1 to Day 10, on a participant account |
| 1 day before | Check every participant can log in and run `conda activate qc && fastp --version` |

## 2. Hardware

| Item | Minimum | Comfortable for 25 participants |
| --- | --- | --- |
| CPU cores | 32 | 64–100 (about 4 per participant) |
| RAM | 128 GB | 256 GB or more |
| Disk | 500 GB | 1–2 TB (reads, databases, everyone's results) |

The Kraken2 standard-8 database needs about 8 GB of RAM per running job. If 25 people run Kraken2 at once, stagger
the session or have half the room use pre-computed reports.

## 3. The shared folder

Create a read-only folder and set `SHARED` to it in the Day 1 setup block:

```text
$SHARED/                                   e.g. /shared/neonatal-amr
├── neonatal-amr-nf/                       the pipeline (this repository)
├── samplesheet.csv                        training set (29 isolates), absolute paths to reads
├── data/                                  downloaded reads (training set)
├── training_data/                         metadata_compact.tsv, ast_compact.tsv, published_K_O_all.tsv, ...
├── databases/
│   ├── kraken2/                           Kraken2 standard-8 (with Bracken files)
│   ├── amrfinderplus/latest/              AMRFinderPlus database, plus amrfinderdb.tar.gz
│   ├── checkm2/uniref100.KO.1.dmnd
│   └── bakta/db-light/
├── precomputed/                           section 7
├── capstone/                              samplesheet.csv, metadata_capstone.tsv, ast_capstone.tsv, precomputed/
└── public_genomes/ST39/                   optional, Day 9
```

```bash
export SHARED=/shared/neonatal-amr
mkdir -p $SHARED && cp -r neonatal-amr-nf $SHARED/
cp -r $SHARED/neonatal-amr-nf/training_data $SHARED/
```

## 4. Training data

The training sets are already in `training_data/`. To regenerate them from the study's supplementary spreadsheet
(`13073_2024_1342_MOESM2_ESM.xlsx` from [the paper](https://doi.org/10.1186/s13073-024-01342-3)):

```bash
cd $SHARED/neonatal-amr-nf
for size in compact capstone full; do
    python3 bin/select_training_set.py 13073_2024_1342_MOESM2_ESM.xlsx training_data --size $size
done
```

| Set | Isolates | Used for |
| --- | --- | --- |
| `compact` | 29 | Days 1–9 |
| `capstone` | 36 (full minus compact) | Day 10 |
| `full` | 65 | Optional larger course, or trainers' reference run |

Download the reads from ENA and write the sample sheets (check with `--dry-run` first):

```bash
cd $SHARED
python3 neonatal-amr-nf/bin/fetch_ena.py fetch neonatal-amr-nf/training_data/accessions_training_compact.tsv \
    -d data -o samplesheet.csv --dry-run
python3 neonatal-amr-nf/bin/fetch_ena.py fetch neonatal-amr-nf/training_data/accessions_training_compact.tsv \
    -d data -o samplesheet.csv --threads 4

python3 neonatal-amr-nf/bin/fetch_ena.py fetch neonatal-amr-nf/training_data/accessions_training_capstone.tsv \
    -d capstone/data -o capstone/samplesheet.csv --threads 4
cp training_data/metadata_capstone.tsv training_data/ast_capstone.tsv capstone/
```

Expect about 20–30 GB for the training set. The script checks every file against ENA's MD5 and skips files
already downloaded, so you can re-run it after an interruption.

> [!IMPORTANT]
> The Day 1 setup links reads by reading the sample sheet's columns in order
> (`sample,species,fastq_1,fastq_2,long_fastq,phylo_group`). Keep that column order, and keep absolute paths.

## 5. Databases

| Database | Used on | How to get it |
| --- | --- | --- |
| Kraken2 standard-8 (with Bracken files) | Day 1 | Download the latest `k2_standard_08gb` from the [Kraken2 index page](https://benlangmead.github.io/aws-indexes/k2) and unpack it into `databases/kraken2/` |
| AMRFinderPlus | Days 3–5 | `amrfinder_update -d $SHARED/databases/amrfinderplus`, then `tar czf $SHARED/databases/amrfinderplus/amrfinderdb.tar.gz -C $SHARED/databases/amrfinderplus/latest .` |
| CheckM2 | Day 2 | `checkm2 database --download --path $SHARED/databases/checkm2` |
| Bakta (light) | Day 5 | `bakta_db download --output $SHARED/databases/bakta --type light` |

> [!NOTE]
> Record each database's version or download date and give it to participants. AMRFinderPlus results in
> particular change between database releases.

## 6. Software environments

One conda environment per tool group. Versions match the pipeline's modules where the pipeline uses the tool;
for the rest, pin the current Bioconda release when you build, and write it down.

| Environment | Packages (Bioconda unless noted) |
| --- | --- |
| `qc` | seqkit, fastqc, fastp=1.3.6, nanoplot=1.47.0, filtlong=0.2.1, kraken2=2.1.6, bracken=3.1, multiqc=1.35 |
| `assembly` | shovill=1.1.0, autocycler=0.6.2, flye=2.9.5, raven-assembler=1.6.1, polypolish=0.6.0, pypolca=0.4.0, bwa=0.7.19, quast=5.3.0, checkm2, bandage, seqkit |
| `medaka` | medaka=2.2.2 |
| `typing` | kleborate=3.2.4 (installs Kaptive), mlst, ectyper=1.0.0, ezclermont=1.0.0 |
| `amr` | ncbi-amrfinderplus=4.2.7, abricate |
| `plasmids` | mob_suite=3.1.9, mash, bakta |
| `phylo` | snippy=4.6.0, gubbins=3.3.5, snp-sites=2.5.1, snp-dists=0.8.2, iqtree=3.1.3, seqkit |
| `r-env` | conda-forge: r-base, r-tidyverse, r-ape, r-remotes; Bioconductor: bioconductor-ggtree; then BactDating from GitHub (below) |
| `nextflow` | nextflow (25.04 or later) |

```bash
mamba create -y -n qc -c conda-forge -c bioconda seqkit fastqc fastp=1.3.6 nanoplot=1.47.0 \
    filtlong=0.2.1 kraken2=2.1.6 bracken=3.1 multiqc=1.35
# ...repeat for each environment in the table...

conda activate r-env
Rscript -e 'remotes::install_github("xavierdidelot/BactDating")'
```

> [!WARNING]
> These environments have not been solved together on every platform. If an environment will not solve, split it
> (for example, CheckM2 and Bakta into their own environments) and update the Day 1 table for participants.

## 7. Pre-computed results

Participants run some slow steps on one or two samples, then copy pre-computed results for the rest. Pages expect
these folders:

| Folder | Contents | Used on |
| --- | --- | --- |
| `precomputed/02_assembly/shovill/<sample>/contigs.fa` (and `contigs.gfa`) | Shovill assembly and graph for all 29 | Day 2 |
| `precomputed/02_assembly/autocycler/<sample>/autocycler_out/consensus_assembly.fasta` | 3 hybrid isolates | Day 2 |
| `precomputed/02_assembly/hybrid/<sample>.hybrid.fasta` | 3 polished hybrid assemblies | Day 2 |
| `precomputed/05_plasmids/shortread/<sample>/` | MOB-suite on each Shovill assembly | Day 5 |
| `precomputed/pipeline_results/` | Full pipeline run, training set | Day 5 |
| `capstone/precomputed/` | Full pipeline run, capstone set | Day 10 |

### 7.1 Run the pipeline

```bash
cd $SHARED/precomputed
nextflow run $SHARED/neonatal-amr-nf/main.nf -profile conda \
    --input $SHARED/samplesheet.csv --outdir pipeline_results \
    --kraken2_db $SHARED/databases/kraken2 \
    --amrfinderplus_db $SHARED/databases/amrfinderplus/amrfinderdb.tar.gz

cd $SHARED/capstone
nextflow run $SHARED/neonatal-amr-nf/main.nf -profile conda \
    --input samplesheet.csv --outdir precomputed \
    --kraken2_db $SHARED/databases/kraken2 \
    --amrfinderplus_db $SHARED/databases/amrfinderplus/amrfinderdb.tar.gz
```

### 7.2 Arrange the assembly results for the manual steps

```bash
P=$SHARED/precomputed
R=$P/pipeline_results/02_assembly

for f in $R/shovill/*.contigs.fa; do
    s=$(basename $f .contigs.fa)
    mkdir -p $P/02_assembly/shovill/$s && cp $f $P/02_assembly/shovill/$s/contigs.fa
    [ -f $R/shovill/$s.contigs.gfa ] && cp $R/shovill/$s.contigs.gfa $P/02_assembly/shovill/$s/contigs.gfa
done
for f in $R/autocycler/*.autocycler.fasta; do
    s=$(basename $f .autocycler.fasta)
    mkdir -p $P/02_assembly/autocycler/$s/autocycler_out
    cp $f $P/02_assembly/autocycler/$s/autocycler_out/consensus_assembly.fasta
    cp $R/autocycler/$s.autocycler.gfa $P/02_assembly/autocycler/$s/autocycler_out/consensus_assembly.gfa
done
mkdir -p $P/02_assembly/hybrid && cp $R/hybrid/*.hybrid.fasta $P/02_assembly/hybrid/

# MOB-suite on every Shovill assembly (the pipeline runs it on the best assembly instead)
conda activate plasmids
for d in $P/02_assembly/shovill/*/; do
    s=$(basename $d)
    mob_recon --infile $d/contigs.fa --outdir $P/05_plasmids/shortread/$s -n 8
done
```

### 7.3 Time needed

Planning estimates, not measurements: run 3 isolates first and scale from Nextflow's execution report.

| Run | 32-core server | 128-core HPC |
| --- | --- | --- |
| Training set (29 isolates) | about 4–5 h | about 2.5–3 h |
| Capstone set (36 isolates) | about 5–6 h | about 3 h |
| MOB-suite on 29 Shovill assemblies | under 1 h | under 30 min |

## 8. Known gaps and decisions for you

- **No *E. coli* in the training data.** The *E. coli* steps (Day 3, section 3.5) are optional. If you add
  *E. coli* genomes, give them sample IDs starting `EC_` and species `ecoli` in the sample sheet.
- **AST is disc diffusion from the original study**, with a different panel per period. Ceftriaxone is
  represented by the cefpodoxime disc. Tell participants which breakpoint standard you assume.
- **Public ST39 genomes for Day 9** (option B) are not provided; download a set from Pathogenwatch or NCBI if you
  plan to use that option.
- **Dates are years only**, so the Day 7 dating exercise is about judging temporal signal, not producing precise
  dates.
- **Commands depend on tool versions.** Column names in Kleborate, AMRFinderPlus and Gubbins outputs have changed
  between versions. The course uses column-name matching where it can, but run every page once on your server.

---

[Course home](README.md) · **Trainer guide**
