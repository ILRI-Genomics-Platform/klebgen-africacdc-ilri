//
// NEONATAL_AMR: bacterial genomic surveillance of neonatal K. pneumoniae
// species complex and E. coli isolates (Illumina + optional ONT reads).
//
// Course module map:
//   READ_QC     -> Module 1   (QC, contamination)
//   ASSEMBLY    -> Module 2   (short-read, long-read and hybrid assembly)
//   TYPING_AMR  -> Modules 3, 4, 5, 7 (typing, AMR/virulence, plasmids, K/O)
//   PHYLOGENY   -> Module 6   (recombination-aware trees, SNP distances)
//   MULTIQC     -> Module 8   (summary report; integration in R is an exercise)
//

include { READ_QC    } from '../subworkflows/local/read_qc/main'
include { ASSEMBLY   } from '../subworkflows/local/assembly/main'
include { TYPING_AMR } from '../subworkflows/local/typing_amr/main'
include { PHYLOGENY  } from '../subworkflows/local/phylogeny/main'
include { MULTIQC    } from '../modules/nf-core/multiqc/main'

workflow NEONATAL_AMR {

    take:
    ch_samplesheet   // [ meta, [ fastq_1, fastq_2 ], long_fastq | [] ]

    main:
    READ_QC(ch_samplesheet, params.kraken2_db)

    ASSEMBLY(READ_QC.out.short_reads, READ_QC.out.long_reads)

    TYPING_AMR(ASSEMBLY.out.assembly, params.amrfinderplus_db)

    if (!params.skip_phylogeny) {
        PHYLOGENY(
            READ_QC.out.short_reads,
            ASSEMBLY.out.assembly,
            params.phylo_references,
            params.phylo_min_group_size
        )
    }

    //
    // Software versions: every module publishes [process, tool, version] to the
    // 'versions' topic; collect them into one YAML file (also shown in MultiQC).
    //
    ch_versions_yml = channel.topic('versions')
        .map { process, tool, version -> [process.tokenize(':').last(), tool, version.toString().trim()] }
        .unique()
        .collect(flat: false)
        .map { rows -> versionsToYaml(rows) }
        .collectFile(
            storeDir: "${params.outdir}/pipeline_info",
            name: 'neonatal_amr_software_mqc_versions.yml',
            newLine: true
        )

    //
    // MultiQC summary report
    //
    ch_multiqc_files = READ_QC.out.multiqc
        .mix(ASSEMBLY.out.multiqc)
        .mix(ch_versions_yml)
        .collect()
    ch_multiqc_config = params.multiqc_config ? file(params.multiqc_config, checkIfExists: true) : []
    MULTIQC(
        ch_multiqc_files.map { files -> [[id: 'neonatal_amr'], files, ch_multiqc_config, [], [], []] }
    )

    emit:
    assembly  = ASSEMBLY.out.assembly
    kleborate = TYPING_AMR.out.kleborate
    amrfinder = TYPING_AMR.out.amrfinder
    multiqc   = MULTIQC.out.report
}

//
// Turn [process, tool, version] rows into MultiQC "software versions" YAML
//
def versionsToYaml(List rows) {
    def byProcess = [:].withDefault { [:] }
    rows.each { row -> byProcess[row[0]][row[1]] = row[2] }
    return byProcess
        .sort()
        .collect { process, tools ->
            "${process}:\n" + tools.sort().collect { tool, version -> "    ${tool}: \"${version}\"" }.join('\n')
        }
        .join('\n')
}
