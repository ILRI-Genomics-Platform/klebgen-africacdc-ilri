# neonatal-amr-nf

A training pipeline for neonatal AMR genomic surveillance of the *Klebsiella pneumoniae* species complex and
*Escherichia coli*, using Illumina reads and, where available, Oxford Nanopore (ONT) reads. It follows nf-core
conventions: official nf-core modules where they exist, local modules (same `main.nf` / `meta.yml` /
`environment.yml` layout) where they do not, one subworkflow per group of course modules, and all tool
arguments in `conf/modules.config`.

**Course materials:** the 10-day course that uses this pipeline, with one page per day, is in
[`course/README.md`](course/README.md). Trainers start with [`course/TRAINER_GUIDE.md`](course/TRAINER_GUIDE.md).

This is a teaching pipeline, not a validated production pipeline. For routine surveillance, validate it
against reference isolates first or use an established community pipeline.

## Layout

```
neonatal-amr-nf/
├── main.nf                         entry point
├── nextflow.config                 parameters and profiles
├── modules.json                    nf-core module versions (nf-core/modules @ c8cb89b, 7 Oct 2026)
├── conf/
│   ├── base.config                 CPU / memory / time per process label
│   ├── modules.config              tool arguments (ext.args) and output folders
│   └── test.config                 stub-test profile
├── workflows/neonatal_amr.nf       the analysis workflow
├── subworkflows/local/
│   ├── utils_neonatal_amr_pipeline samplesheet reading and validation
│   ├── read_qc                     Module 1
│   ├── assembly                    Module 2
│   ├── typing_amr                  Modules 3, 4, 5, 7
│   └── phylogeny                   Module 6
├── modules/
│   ├── nf-core/                    19 official modules (do not edit; update with nf-core tools)
│   └── local/                      5 pipeline-specific modules
├── assets/                         example samplesheet, accession template, stub test data
├── bin/                            select_training_set.py, fetch_ena.py
├── training_data/                  training sets (29 / 36 capstone / 65), metadata, AST, K/O types (Blantyre study)
└── course/                         the course: README plus one page per day, and a trainer guide
```

## Modules

| Step | Module | Source | Version |
| --- | --- | --- | --- |
| Illumina trimming | `fastp` | nf-core | 1.3.6 |
| ONT filtering / QC | `filtlong`, `nanoplot` | nf-core | 0.2.1 / 1.47.0 |
| Contamination | `kraken2/kraken2`, `bracken/bracken` | nf-core | 2.1.6 / 3.1 |
| Short-read assembly | `shovill` | nf-core | 1.1.0 |
| Long-read consensus assembly | `autocycler/assemble` | **local** | Autocycler 0.6.2, Flye 2.9.5, Raven 1.6.1 |
| Long-read polishing | `medaka` | nf-core | 2.2.2 |
| Short-read polishing | `polypolish/shortread` | **local** | Polypolish 0.6.0, BWA 0.7.19 |
| Short-read polishing | `pypolca/run` | nf-core | 0.4.0 |
| Assembly QC | `quast` | nf-core | 5.3.0 |
| Typing, AMR, virulence, K/O | `kleborate` | **local** | 3.2.4 |
| AMR genes and mutations | `amrfinderplus/update`, `amrfinderplus/run` | nf-core | 4.2.7 |
| Plasmids | `mobsuite/recon` | nf-core | 3.1.9 |
| *E. coli* serotype | `ectyper` | nf-core | 1.0.0 |
| *E. coli* phylogroup | `ezclermont` | **local** | 1.0.0 |
| Core SNPs | `snippy/run`, `snippy/core` | nf-core | 4.6.0 |
| Alignment cleaning | `snippy/clean` | **local** | snippy 4.6.0 |
| Recombination | `gubbins` | nf-core | 3.3.5 |
| Tree | `iqtree` | nf-core | 3.1.3 |
| SNP distances | `snpdists` | nf-core | 0.8.2 |
| Report | `multiqc` | nf-core | 1.35 |

Why the local modules exist:

- **kleborate**: the nf-core module is pinned to Kleborate v2.1.0; the course uses v3 (minimap2, presets, *E. coli* MLST).
- **autocycler/assemble**: nf-core has Autocycler's sub-commands but no module for building the input assemblies, so the full recipe is one process. Splitting it into the nf-core sub-modules is a trainee exercise.
- **polypolish/shortread**: Polypolish needs each read file aligned separately with `bwa mem -a` and then filtered; the nf-core module covers only the final `polish` step.
- **ezclermont**: no nf-core module exists for Clermont phylotyping.
- **snippy/clean**: runs `snippy-clean_full_aln` and names the alignment after the phylogeny group, because the nf-core `gubbins` module has no `meta` map.

Local modules pin conda packages in `environment.yml` but do not pin a container image. Use `-profile conda` or
`mamba`, or add `wave` to a container profile (for example `-profile docker,wave`) so Wave builds their containers
from `environment.yml`. Version numbers come from the module files; where a module came from nf-core, so did its pin.

## Samplesheet

```csv
sample,species,fastq_1,fastq_2,long_fastq,phylo_group
CHI11E,kpneumoniae,data/raw/ERR12058885_1.fastq.gz,data/raw/ERR12058885_2.fastq.gz,data/CHI11E_ont.fastq.gz,ST39
CAA65Z,kpneumoniae,data/raw/ERR12058332_1.fastq.gz,data/raw/ERR12058332_2.fastq.gz,,ST39
```

- `species`: `kpneumoniae` (any *K. pneumoniae* species complex member) or `ecoli`.
- `long_fastq`: optional ONT reads; their presence switches that isolate to hybrid assembly.
- `phylo_group`: optional label; isolates sharing it get one recombination-filtered phylogeny and SNP-distance matrix (Module 6). Groups smaller than `--phylo_min_group_size` (default 3) are skipped.
- Relative paths are read relative to the samplesheet's folder.

## Running

```bash
# 1. Choose isolates from the Genome Medicine 2024 supplementary tables, or use training_data/
#    (--size compact = 29, capstone = 36 unseen, full = 65; also writes metadata, AST and K/O tables)
python3 bin/select_training_set.py 13073_2024_1342_MOESM2_ESM.xlsx training_data --size compact

# 2. Download them from ENA and write the samplesheet (MD5-checked; try --dry-run first)
python3 bin/fetch_ena.py fetch training_data/accessions_training_compact.tsv -d data -o samplesheet.csv

# 3. Run
nextflow run main.nf -profile docker,wave \
    --input samplesheet.csv \
    --outdir results \
    --kraken2_db /path/to/k2_standard_08gb \
    --amrfinderplus_db /path/to/amrfinderdb.tar.gz     # omit to download the latest
```

Add `-profile laptop` on an 8-core / 32 GB machine, or `-profile slurm` on a cluster. Requires Nextflow 25.04 or later.

| Parameter | Default | Meaning |
| --- | --- | --- |
| `--input` | | Samplesheet CSV |
| `--outdir` | `results` | Output folder |
| `--kraken2_db` | none | Kraken2 database folder (with Bracken files); omit to skip the contamination check |
| `--amrfinderplus_db` | none | AMRFinderPlus database; omit to download the latest (its date is recorded) |
| `--phylo_references` | none | CSV `group,fasta` of reference genomes; by default each group's own best assembly (hybrid first, then fewest contigs) |
| `--phylo_min_group_size` | 3 | Smallest group that gets a phylogeny |
| `--skip_phylogeny` | false | Skip Module 6 |

## Outputs

```
results/
├── 01_qc/            fastp, filtlong, nanoplot, kraken2, bracken
├── 02_assembly/      shovill, autocycler, hybrid, quast
├── 03_typing/        kleborate, ectyper, ezclermont
├── 04_amr/           amrfinderplus
├── 05_plasmids/      mobsuite
├── 06_phylogeny/     <group>/ (core alignment, tree, SNP distances, snippy), gubbins/
├── multiqc/          multiqc_report.html
└── pipeline_info/    software versions, execution report, timeline, trace
```

## Testing

```bash
nextflow run main.nf -profile test -stub --outdir test_results
```

The stub test uses placeholder reads in `assets/test_data` (8 samples: an ST39 group of 4, one with ONT reads; an
ST35 group of 2, which is skipped; one ungrouped *K. pneumoniae*; one *E. coli* with ONT reads). Stub mode checks
that every channel connects without running the tools, but nf-core modules still run their version commands, so
run it inside a container profile (for example `-profile test,docker,wave -stub`) or with the tools installed.

## Exercises built into the pipeline

1. Add the nf-core `checkm2/predict` module after assembly and drop isolates above 5% contamination.
2. Replace `autocycler/assemble` with the nf-core Autocycler sub-modules plus `flye` and `raven` modules.
3. Add ABRicate (ResFinder, VFDB) and compare its calls with AMRFinderPlus.
4. Write an R script that joins Kleborate, AMRFinderPlus, MOB-suite and metadata by sample ID (Module 8).
5. Add BactDating on the IQ-TREE output for time-scaled trees.

## Citations

Cite the source study and BioProjects for the training data (Heinz et al., Genome Medicine 2024,
doi:10.1186/s13073-024-01342-3; ERP126322, ERP021324, ERP009326, ERP115360, PRJNA641987), nf-core
(Ewels et al., Nat Biotechnol 2020) and each tool listed above.
