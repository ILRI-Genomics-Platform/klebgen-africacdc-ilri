#!/usr/bin/env nextflow
/*
========================================================================================
    neonatal-amr-nf
========================================================================================
    Training pipeline for neonatal AMR genomic surveillance of the Klebsiella
    pneumoniae species complex and Escherichia coli (Illumina + Oxford Nanopore).

    Layout follows nf-core conventions:
      modules/nf-core/   official nf-core modules (see modules.json for versions)
      modules/local/     pipeline-specific modules (main.nf, meta.yml, environment.yml)
      subworkflows/local one subworkflow per course module group
      workflows/         the main analysis workflow
      conf/              resources (base.config) and tool arguments (modules.config)
----------------------------------------------------------------------------------------
*/

include { PIPELINE_INITIALISATION } from './subworkflows/local/utils_neonatal_amr_pipeline/main'
include { NEONATAL_AMR            } from './workflows/neonatal_amr'

workflow {
    main:
    PIPELINE_INITIALISATION(params.input)
    NEONATAL_AMR(PIPELINE_INITIALISATION.out.samplesheet)
}
