// Local module: Kleborate v3.
// The nf-core 'kleborate' module is pinned to v2.1.0, which predates the v3
// rewrite (minimap2, modular presets, E. coli MLST) used in this course.
process KLEBORATE {
    tag "$meta.id"
    label 'process_low'

    conda "${moduleDir}/environment.yml"
    // No container pinned: with -profile wave, a container is built from environment.yml

    input:
    tuple val(meta), path(fasta)

    output:
    tuple val(meta), path("${prefix}.kleborate.txt"), emit: txt
    tuple val("${task.process}"), val('kleborate'), eval("kleborate --version 2>&1 | sed 's/^.*Kleborate v//; s/ .*//'"), emit: versions_kleborate, topic: versions

    when:
    task.ext.when == null || task.ext.when

    script:
    def args   = task.ext.args ?: ''
    prefix     = task.ext.prefix ?: "${meta.id}"
    // kpsc = Klebsiella pneumoniae species complex (species, MLST, AMR, virulence, K/O via Kaptive)
    // escherichia = E. coli MLST (Achtman and Pasteur schemes)
    def preset = task.ext.preset ?: (meta.species == 'ecoli' ? 'escherichia' : 'kpsc')
    """
    kleborate \\
        $args \\
        -a $fasta \\
        -p $preset \\
        -o kleborate_out

    cp kleborate_out/*_output.txt ${prefix}.kleborate.txt
    """

    stub:
    prefix = task.ext.prefix ?: "${meta.id}"
    """
    touch ${prefix}.kleborate.txt
    """
}
