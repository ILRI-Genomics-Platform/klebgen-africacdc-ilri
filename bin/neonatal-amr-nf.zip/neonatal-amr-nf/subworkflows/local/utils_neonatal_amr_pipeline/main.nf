//
// PIPELINE_INITIALISATION: read and validate the samplesheet.
//
// Samplesheet (CSV, header required):
//   sample,species,fastq_1,fastq_2,long_fastq,phylo_group
//   - species     : kpneumoniae | ecoli
//   - fastq_1/2   : paired-end Illumina reads (required)
//   - long_fastq  : Oxford Nanopore reads (optional; triggers hybrid assembly)
//   - phylo_group : optional label (e.g. ST39); isolates sharing a label are
//                   analysed together in the phylogeny/transmission step
//
// Validation is written out in Groovy rather than with the nf-schema plugin
// so that trainees can read every rule and the pipeline runs offline.
//

workflow PIPELINE_INITIALISATION {

    take:
    input    // path to samplesheet CSV

    main:
    if (!input) {
        error("Please provide a samplesheet with --input (see assets/samplesheet.csv)")
    }
    def sheet = file(input, checkIfExists: true)

    ch_samplesheet = channel
        .fromPath(sheet)
        .splitCsv(header: true, strip: true)
        .map { row -> validateRow(row, validSpecies(), sheet.parent) }

    // Duplicate sample IDs would silently overwrite each other's results
    ch_samplesheet
        .map { meta, _sr, _lr -> meta.id }
        .collect()
        .map { ids ->
            def dups = ids.countBy { it }.findAll { _id, n -> n > 1 }.keySet()
            if (dups) {
                error("Samplesheet: duplicate sample IDs: ${dups.join(', ')}")
            }
        }

    emit:
    samplesheet = ch_samplesheet   // [ meta, [ fastq_1, fastq_2 ], long_fastq | [] ]
}

//
// Species the pipeline knows how to type
//
def validSpecies() {
    return ['kpneumoniae', 'ecoli']
}

//
// Validate one samplesheet row and build the meta map
//
def validateRow(Map row, List validSpecies, Path sheetDir) {
    def required = ['sample', 'species', 'fastq_1', 'fastq_2']
    def missing = required.findAll { col -> !row[col] }
    if (missing) {
        error("Samplesheet row ${row}: missing value(s) for ${missing.join(', ')}")
    }
    if (!(row.sample ==~ /[A-Za-z0-9_.-]+/)) {
        error("Samplesheet: sample '${row.sample}' may only contain letters, digits, '_', '.' and '-'")
    }
    def species = row.species.toLowerCase()
    if (!(species in validSpecies)) {
        error("Samplesheet: sample '${row.sample}' has species '${row.species}'; expected one of ${validSpecies.join(', ')}")
    }
    def group = row.phylo_group ?: null
    if (group && !(group ==~ /[A-Za-z0-9_-]+/)) {
        error("Samplesheet: phylo_group '${group}' (sample ${row.sample}) may only contain letters, digits, '_' and '-'")
    }

    def meta = [
        id          : row.sample,
        species     : species,
        single_end  : false,
        phylo_group : group,
        has_long    : row.long_fastq ? true : false,
    ]
    def short_reads = [resolvePath(row.fastq_1, sheetDir), resolvePath(row.fastq_2, sheetDir)]
    def long_reads  = row.long_fastq ? resolvePath(row.long_fastq, sheetDir) : []
    return [meta, short_reads, long_reads]
}

//
// Relative paths in the samplesheet are read relative to the samplesheet's folder
//
def resolvePath(String path, Path sheetDir) {
    def isRemoteOrAbsolute = path ==~ /^[a-zA-Z][a-zA-Z0-9+.-]*:\/\/.*/ || path.startsWith('/')
    return file(isRemoteOrAbsolute ? path : "${sheetDir}/${path}", checkIfExists: true)
}
