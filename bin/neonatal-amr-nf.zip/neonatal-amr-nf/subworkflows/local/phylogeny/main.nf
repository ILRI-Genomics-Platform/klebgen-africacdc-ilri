//
// PHYLOGENY (Module 6): one recombination-aware phylogeny and SNP-distance
// matrix per phylo_group (e.g. one ST), for transmission analysis.
//
//   reads --snippy--> core alignment --clean--> Gubbins --> IQ-TREE
//                                                     \--> snp-dists
//
// Reference per group: from --phylo_references (CSV: group,fasta) if given;
// otherwise the group's best own assembly (hybrid first, then fewest contigs).
//

include { SNIPPY_RUN   } from '../../../modules/nf-core/snippy/run/main'
include { SNIPPY_CORE  } from '../../../modules/nf-core/snippy/core/main'
include { GUBBINS      } from '../../../modules/nf-core/gubbins/main'
include { IQTREE       } from '../../../modules/nf-core/iqtree/main'
include { SNPDISTS     } from '../../../modules/nf-core/snpdists/main'
include { SNIPPY_CLEAN } from '../../../modules/local/snippy/clean/main'

workflow PHYLOGENY {

    take:
    ch_short_reads      // [ meta, [ R1, R2 ] ]
    ch_assembly         // [ meta, fasta ]
    phylo_references    // CSV group,fasta or null
    min_group_size      // groups smaller than this are skipped

    main:
    ch_reads_grouped = ch_short_reads.filter { meta, _reads -> meta.phylo_group }

    // ---- choose one reference genome per group
    if (phylo_references) {
        ch_refs = channel
            .fromPath(phylo_references, checkIfExists: true)
            .splitCsv(header: true, strip: true)
            .map { row -> [row.group, file(row.fasta, checkIfExists: true)] }
    } else {
        ch_refs = ch_assembly
            .filter { meta, _fasta -> meta.phylo_group }
            .map { meta, fasta ->
                // rank: hybrid assemblies first, then fewest contigs
                def rank = [meta.assembly_type == 'hybrid' ? 0 : 1, fasta.countFasta(), meta.id]
                [meta.phylo_group, rank, fasta]
            }
            .groupTuple()
            .map { group, ranks, fastas ->
                // order by assembly type, then contig count, then sample ID
                def best = (0..<ranks.size()).toList().sort { a, b ->
                    (ranks[a][0] <=> ranks[b][0]) ?: (ranks[a][1] <=> ranks[b][1]) ?: (ranks[a][2] <=> ranks[b][2])
                }.first()
                log.info "Phylogeny group ${group}: reference = ${ranks[best][2]} (${fastas[best].name})"
                [group, fastas[best]]
            }
    }

    // ---- keep groups with enough isolates
    ch_group_sizes = ch_reads_grouped
        .map { meta, _reads -> [meta.phylo_group, meta.id] }
        .groupTuple()
        .map { group, ids -> [group, ids.size()] }
    ch_kept_groups = ch_group_sizes
        .filter { group, n ->
            if (n < min_group_size) {
                log.warn "Phylogeny group ${group} has ${n} isolate(s) (< ${min_group_size}); skipped"
            }
            n >= min_group_size
        }
        .map { group, _n -> group }

    // ---- map each isolate's reads to its group reference
    ch_snippy_in = ch_reads_grouped
        .map { meta, reads -> [meta.phylo_group, meta, reads] }
        .combine(ch_kept_groups, by: 0)
        .combine(ch_refs, by: 0)
        .multiMap { _group, meta, reads, ref ->
            reads: [meta, reads]
            ref:   ref
        }
    SNIPPY_RUN(ch_snippy_in.reads, ch_snippy_in.ref)

    // ---- one core alignment per group
    ch_core_in = SNIPPY_RUN.out.vcf
        .join(SNIPPY_RUN.out.aligned_fa)
        .map { meta, vcf, aligned -> [meta.phylo_group, vcf, aligned] }
        .groupTuple()
        .combine(ch_refs, by: 0)
        .multiMap { group, vcfs, aligned, ref ->
            core: [[id: group], vcfs, aligned]
            ref:  ref
        }
    SNIPPY_CORE(ch_core_in.core, ch_core_in.ref)
    SNIPPY_CLEAN(SNIPPY_CORE.out.full_aln)

    // ---- remove recombination, then build the tree on the filtered SNP sites.
    // nf-core gubbins has no meta map; outputs are named after the input file
    // (<group>.aln), so the group ID is recovered from the file name.
    GUBBINS(SNIPPY_CLEAN.out.aln.map { _meta, aln -> aln })
    ch_snps = GUBBINS.out.fasta.map { fasta -> [[id: fasta.name.tokenize('.')[0]], fasta] }

    IQTREE(ch_snps.map { meta, fasta -> [meta, fasta, []] }, [], [], [], [], [], [], [], [], [], [], [], [])
    SNPDISTS(ch_snps)

    emit:
    core_aln      = SNIPPY_CORE.out.aln            // [ meta(group), aln ]
    gubbins_tree  = GUBBINS.out.tree
    tree          = IQTREE.out.phylogeny           // [ meta(group), treefile ]
    snp_distances = SNPDISTS.out.tsv               // [ meta(group), tsv ]
}
